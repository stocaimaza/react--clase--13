
import { initializeApp } from "firebase/app";
import {getFirestore} from "firebase/firestore"
//Vamos a importar dos funciones de la librería Firebase. 
//initializeApp = se usa para inicializar una instancia de Firebase en la APP. 
//getFirestore = se utiliza para obtener una instancia de Firestore. 

//Creamos un objeto con toda nuestra información de la cuenta. 
const firebaseConfig = {
  apiKey: "AIzaSyCaKok-cSCtToutbv31arA83pds0H9w7NM",
  authDomain: "marolio-908bb.firebaseapp.com",
  projectId: "marolio-908bb",
  storageBucket: "marolio-908bb.appspot.com",
  messagingSenderId: "208280765006",
  appId: "1:208280765006:web:24b45bf6871068cbf3391f"
};

// Inicializamos Firebase y se pasa la configuración como argumento. Esto devuelve una instancia de Firebase. 
const app = initializeApp(firebaseConfig);

//Uso esa instancia de Firebase para obtener una instancia de Firestore. 

export const db = getFirestore(app); 
//Exportamos esta referencia para que este disponible en toda nuestra aplicación. 