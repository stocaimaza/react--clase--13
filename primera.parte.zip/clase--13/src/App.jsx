import './App.css';
import Productos from './components/Productos/Productos';

function App() {
  return (
    <div className="App">
     muchaaaaachosss
     <Productos />
    </div>
  );
}

export default App;
