import { useState, useEffect } from "react";
//Importamos los hooks que vamos a utilizar. 

import { getDocs, collection, query, where } from "firebase/firestore"
//Importamos las funciones que vamos a utilizar: 
//Recuerden en Firestore las colecciones tiene documentos en su interior. 
//collection me permite obtener una colección. 
//getDocs me permite obtener los documentos de una colección. 
//query la uso cuando quiero generar una consulta. 
//where la uso para agregar filtros a mis consultas. 

import { db } from "../../services/firebase/config";
//Importamos el objeto que tiene mi configuración para conectarme a la base de datos. 

const Productos = () => {
    const [productos, setProductos] = useState([]);

    useEffect(() => {
        const misProductos = query(collection(db, "productos"), where("precio", "<",200));

        //getDocs me retorna una promesa. 
        getDocs(misProductos)
            .then((respuesta) => {
                setProductos(respuesta.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
                //Creo un nuevo array que contenga los datos del producto y además el id. 
            })
    }, [])
    //Obtengo los datos cuando se monta el componente

    return (
        <div>
            <h2>Productos</h2>
            {
                productos.map((producto) => (
                    <div key={producto.id}>
                        <h2> {producto.nombre} </h2>
                        <p>Precio: $ {producto.precio} </p>
                        <p>Stock: {producto.stock} </p>
                        <button> Agregar al Carrito </button>
                    </div>
                ))
            }

        </div>
    )
}

export default Productos